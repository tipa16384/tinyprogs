# globals.py

_WALL = '@'
_EMPTY = ' '
_BASE = 'a'
_FLOOR = '.'

_ROOMW = 100
_ROOMH = 40
_NROOMS = 26

_N = -_ROOMW
_E = 1
_S = _ROOMW
_W = -1
_NW = -_ROOMW-1
_NE = -_ROOMW+1
_SW = _ROOMW-1
_SE = _ROOMW+1
