#!/usr/bin/python

from board import Board

board = Board()

board.show()

