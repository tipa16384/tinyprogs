# 7DRL
# Class for a square of the room

from gamevars import _WALL, _EMPTY, _FLOOR
from gamevars import _N, _E, _W, _S

class Spot:
	def __init__(self,num):
		self.code = _WALL
		self.num = num
		self.dirs = { _N:None, _E:None, _W:None, _S:None }
		self.interior = False
		
	def getCode(self):
		return self.code

	def setCode(self,code):
		self.code = code

	def isRoom(self):
		return self.code != _WALL and self.code != _EMPTY

	def getNumber(self):
		return self.num

	def isInterior(self):
		return self.interior
	
	def setInterior(self,inside):
		self.interior = inside

	def look(self,at):
		try:
			return self.dirs[at]
		except KeyError:
			return None
	
	def setDoor(self,at,door):
		self.dirs[at] = door
		
	def __str__(self):
		for d in self.dirs.values():
			if d is not None:
				return self.code.upper()
		if self.interior:
			return _FLOOR
		else:
			return self.code
