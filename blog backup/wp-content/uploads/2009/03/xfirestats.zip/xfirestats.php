<?php
/**
 * @package XFire_Stats
 * @author Brenda Holloway
 * @version 0.7c
 */
/*
Plugin Name: XFire Stats
Plugin URI: http://westkarana.com/index.php/xfire-plugin
Description: The XFire Stats plugin adds a widget that displays the games played over the past week along with the time spent playing each one, as tracked by the XFire application. You must set your XFire ID in the widget's options to see any results. Check the "now playing" box to display an additional line that shows the game you are currently playing.
Author: Brenda Holloway
Version: 0.7c
Author URI: http://westkarana.com
*/

function xfirestats_init() {

	if ( !function_exists('register_sidebar_widget') || !function_exists('register_widget_control'))
		return;

function get_web_page($url) {
	if (!function_exists('curl_init')) {
		$xmlheader = array();
		$xmlheader['content'] = implode('', file($url));
	} else {
		$ch = curl_init();
		curl_setopt( $ch, CURLOPT_URL, $url );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_HEADER, false );
		curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
		curl_setopt( $ch, CURLOPT_ENCODING, "" );
		curl_setopt( $ch, CURLOPT_USERAGENT, "wordpress widget" );
		curl_setopt( $ch, CURLOPT_AUTOREFERER, true );
		curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, 120 );
		curl_setopt( $ch, CURLOPT_TIMEOUT, 120 );
		curl_setopt( $ch, CURLOPT_MAXREDIRS, 10 );
	
		$content = curl_exec( $ch );
		$err = curl_errno( $ch );
		$errmsg = curl_error( $ch );
		$xmlheader = curl_getinfo( $ch );
		curl_close( $ch );

		$xmlheader['errno'] = $err;
		$xmlheader['errmsg'] = $errmsg;
		$xmlheader['content'] = $content;
	}
	
	return $xmlheader;
}

$game = "No game";
$time = 0;
$lasttag = "none";
$gameid = "";
$firstline = true;
$output = "";
$gamearr = array();
$gameinfo = array();
$fixes = array('wiz101' => 'wizard101');

function fixShort($short) {
	global $fixes;
	$short = trim($short);
	//echo '{{'.$fixes['wiz101'].'}}';
	if (array_key_exists($short,$fixes)) {
		//echo "yay $short " . $fixes[$short];
		return $fixes[$short];
	} else {
		//echo "no match '$short'";
		return $short;
	}
}

function startTag($parser, $data, $attrs) {
	global $lasttag, $gameinfo;

	$lasttag = $data;

	if ($lasttag == 'GAME')
		$gameinfo = array();
		
	//echo '<li>tag is ' . $data . '</li>';
}

function formatTime($time) {
		$hours = (int)($time/3600);
		$mins = (int)($time/60) - ($hours*60);
		$secs = $time%60;
		if ($secs >= 30) $mins++;
		if ($mins > 60) { $hours++; $mins-=60; }
		return sprintf("%d:%02d",$hours,$mins);
}

function endTag($parser, $data) {
	global $game, $time, $gameid, $gamearr, $gameinfo;
	$time = $gameinfo['WEEKTIME'];
	$gameid = fixShort($gameinfo['SHORTNAME']);
	$game = $gameinfo['LONGNAME'];
	if (!strcmp($data,"GAME") && (int)$time > 0) {
		$gamearr[$gameid] = array(-((int)$time),$gameid,(int)$time,$game);
	}
}

function contents($parser, $data) {
	global $lasttag, $game, $time, $gameid, $gameinfo;
	
	//echo "<li>$lasttag data is $data</li>";

	$gameinfo[$lasttag] .= $data;
}

$liveInfo = array();

function liveStartTag($parser, $data, $attrs) {
	global $lasttag, $liveInfo;
	$lasttag = $data;
	if ($data == 'XFIRE')
		$liveInfo = array();
	else if ($data == 'GAME') {
		$liveInfo['ID'] = $attrs['ID'];
		$liveInfo['SHORTNAME'] = fixShort($attrs['SHORTNAME']);
	}
	
	
	//echo '<li>tag is ' . $data . '</li>';
}

function liveEndTag($parser, $data) {
}

function liveContents($parser, $data) {
	global $lasttag, $liveInfo;
	$data = trim($data);
	if (strlen($data) == 0) return;
	//echo "<li>$lasttag data is $data</li>";

	$liveInfo[$lasttag] .= $data;
}

function showOptions($options) {
	echo '<ul>';
	echo '<li>lastupdate = '.$options['lastupdate'].'</li>';
	echo '<li>now = '.time().'</li>';
	echo '<li>liveInfo = '.$options['liveInfo'].'</li>';
	echo '<li>gameInfo = '.$options['gameInfo'].'</li>';
	echo '</ul>';
}


function xfirestats_widget($args) {
	global $lasttag, $game, $time, $gameid, $output;
	global $firstline, $gamearr, $liveInfo, $fixes;
	
	extract($args);

	$defaultupdateInterval = 5 * 60;	// update once an hour

	$game = "No game";
	$time = 0;
	$lasttag = "none";
	$gameid = "";
	$firstline = true;
	$gamearr = array();
	$fixes = array('wiz101' => 'wizard101');
	
	$options = get_option('xfirestats');
	//showOptions($options);
	
	$output = '<table border=0 cellspacing=2 width=100%>';

	$title = htmlspecialchars($options['title'],ENT_QUOTES);

   if (empty($title))
   	$title = htmlspecialchars("XFire Weekly Stats",ENT_QUOTES);

	echo $before_widget;
	echo $before_title . $title . $after_title;

   // Collect our widget's options.
   $player = htmlspecialchars($options['player'],ENT_QUOTES);
   $nowplaying = $options['nowplaying'];
   $lastupdate = $options['lastupdate'];
   $updateinterval = $options['interval'];
   
   if (!$updateinterval) {
   	$updateinterval = $defaultupdateInterval;
   	$options['interval'] = $updateinterval;
   }
   
   $now = time();

   $update = ($nowplaying && !$options['liveInfo'])
   	|| !$options['gameInfo']
   	|| (($now-$lastupdate-$updateInterval) > 0);

	if (empty($player)) {
		$output .= '<tr><td align=center><b>No XFire Id assigned</b></td></tr>';
	} else {
		if ($nowplaying) {
			if ($update) {
				$url = 'http://www.xfire.com/xml/' . $player . '/live/';
				$xmlheader = get_web_page( $url );
				$xml_parser = xml_parser_create();
				xml_set_element_handler($xml_parser,"liveStartTag","liveEndTag");
				xml_set_character_data_handler($xml_parser,"liveContents");

				if (!(xml_parse($xml_parser, $xmlheader['content'], false))) {
					die("Error on line " . xml_get_current_line_number($xml_parser));
				}

				xml_parser_free($xml_parser);
				$options['liveInfo'] = $liveInfo;
			} else {
				$liveInfo = $options['liveInfo'];
			}

			if ($liveInfo['STATUS'] == 'online' && $liveInfo['ID'] > 0) {
				$home = "http://www.xfire.com/profile/$player/";
				$lname = htmlspecialchars($liveInfo['NICKNAME'],ENT_QUOTES);
				$nick = "<a href=\"$home\" text=\"$lname's XFire profile\">$lname</a>";
				$game = "<a href=\"http://www.xfire.com/games/".$liveInfo['SHORTNAME']."/\">".htmlspecialchars($liveInfo['GAME'],ENT_QUOTES)."</a>";
				$output .= "<tr><td colspan=2 style=\"text-align:center;\"><i>$nick is playing $game</i></td></tr><tr><td style=\"font-size:10%;\">&nbsp;</td></tr>";
			}
		}

		if ($update) {
			$url = 'http://www.xfire.com/xml/' . $player . '/gameplay/';
			$xmlheader = get_web_page( $url );
			$xml_parser = xml_parser_create();
			xml_set_element_handler($xml_parser,"startTag","endTag");
			xml_set_character_data_handler($xml_parser,"contents");

			if (!(xml_parse($xml_parser, $xmlheader['content'], false))){
				die("Error on line " . xml_get_current_line_number($xml_parser));
			}

			xml_parser_free($xml_parser);
		
			sort($gamearr);
			$options['gameInfo'] = $gamearr;
		} else {
			$gamearr = $options['gameInfo'];
		}
		
		foreach ($gamearr as $key => $arr) {
			$output .= '<tr><td valign=top align=left>';
			$output .= '<a href="http://www.xfire.com/games/'.$arr[1].'/">';
			$output .= htmlspecialchars($arr[3], ENT_QUOTES);
			$output .= '</a></td><td valign=top align=right>';
			$output .= formattime($arr[2]);
			$output .= '</td></tr>';
		}
	}
	
	if ($update) {
		$options['lastupdate'] = $now;
		$lastupdate = $now;
		update_option('xfirestats', $options);
	}
	
	/*
	$output .= '<tr><td style="font-size:smaller;text-align:center;">';
	$output .= 'last updated ' . date('d M y h:ia',$lastupdate);
	$output .= '</td></tr>';
	*/
	
	$output .= '</table>';
	echo $output;
	
	echo $after_widget;
}

    function widget_mywidget_control() {

        // Collect our widget's options.
        $options = get_option('xfirestats');
        
        // This is for handing the control form submission.
        if ( $_POST['xfirestats-submit'] ) {
            // Clean up control form submission options
            $newoptions = array();
            $newoptions['player'] = strip_tags(stripslashes($_POST['xfirestats-player']));
            $newoptions['title'] = strip_tags(stripslashes($_POST['xfirestats-title']));
            $newoptions['nowplaying'] = strip_tags(stripslashes($_POST['xfirestats-nowplaying']));
				$newoptions['interval'] = 5 * 60;
				
				if ($options != $newoptions) {
					$options = $newoptions;
					update_option('xfirestats', $options);
				}
        }

        $player = htmlspecialchars($options['player'], ENT_QUOTES);
        $title = htmlspecialchars($options['title'], ENT_QUOTES);
        $nowplaying = htmlspecialchars($options['nowplaying'], ENT_QUOTES);

// The HTML below is the control form for editing options.
?>
        <div>
        <label for="xfirestats-player" style="line-height:35px;display:block;">XFire Id: <input type="text" id="xfirestats-player" name="xfirestats-player" value="<?php echo $player; ?>" /></label>
        <label for="xfirestats-title" style="line-height:35px;display:block;">Widget Title: <input type="text" id="xfirestats-title" name="xfirestats-title" value="<?php echo $title; ?>" /></label>
        <label for="xfirestats-nowplaying" style="line-height:35px;display:block;">Show Now Playing line: <input type="checkbox" id="xfirestats-nowplaying" name="xfirestats-nowplaying" value="1" <?php if ($nowplaying) echo ' checked '; ?> /></label>
        <input type="hidden" name="xfirestats-submit" id="xfirestats-submit" value="1" />
        </div>
    <?php
    // end of widget_mywidget_control()
    }

register_sidebar_widget('XFire Stats', 'xfirestats_widget');
    // This registers the (optional!) widget control form.
    register_widget_control('XFire Stats', 'widget_mywidget_control');
}

if(defined('xfs_loaded')) {
	return;
}
define('xfs_loaded', 1);

add_action('plugins_loaded', 'xfirestats_init');

?>
