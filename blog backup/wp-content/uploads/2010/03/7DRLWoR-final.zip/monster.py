# monster.py

from gamevars import *
import pygame
import pygame.time
from pygame.locals import *
from pygame.sprite import *
import pygame.event
from pygame import Rect
from random import randint, choice, shuffle
from math import pow, sqrt
from items import getAwesome

from object import Object

class Monster(Object):
	def __init__(self):
		Object.__init__(self)
		self.setDesc('Monster')
		self.setLDesc('a monster')
		self.setType(O_MONSTER)
		self.speed = OSPEED
		self.mood = M_DOCILE
		self.state = S_NORMAL
		self.newPos = None
		self.goal = None
		self.maxHitPoints = 1
		self.hitPoints = self.maxHitPoints
		self.minDamage = 1
		self.maxDamage = 1
		self.level = 0
		self.moving = True
		
	def canMove(self,facing,board,group):
		if not self.moving:
			return False
			
		okay = False
		self.newPos = None
		
		dx = 0
		dy = 0
		
		x = self.pos[0]
		y = self.pos[1]

		if facing == N:
			dy = -1
		elif facing == NW:
			dx = -1
			dy = -1
		elif facing == W:
			dx = -1
		elif facing == SW:
			dx = -1
			dy = 1
		elif facing == S:
			dy = 1
		elif facing == SE:
			dy = 1
			dx = 1
		elif facing == E:
			dx = 1
		elif facing == NE:
			dx = 1
			dy = -1
		
		nx = x + dx
		ny = y + dy
		
		if nx < 1:
			nx = 1
		elif nx > ROOMW-2:
			nx = ROOMW-2
		if ny < 1:
			ny = 1
		elif ny > ROOMH-2:
			ny = ROOMH-2
		
		if x != nx or y != ny:
			spot = board.getAt(x,y)
			nspot = board.getAt(nx,ny)
		
			if spot.getCode() == nspot.getCode():
				okay = True
			elif nspot.isRoom():
				if facing == N or facing == E or facing == W or facing == S:
					door = spot.look(facing)
					if door is not None:
						okay = True
		
			npos = (nx,ny)
			
			if okay:
				for mob in group:
					if mob != self and mob.getPos() == npos and mob.getType() > O_GENERIC:
						okay = False
						break
						
			if okay:
				self.newPos = npos

		return okay
	
	def doSomething(self,board,player,group,screen):
		ppos = player.getPos()
		pspot = board.getAt(ppos[0],ppos[1])
		proom = pspot.getCode()
		pos = self.getPos()
		spot = board.getAt(pos[0],pos[1])
		room = spot.getCode()
		
		mpos = self.getPos()
		
		if proom == room:
			self.mood = M_HOSTILE
			dist = sqrt(pow(mpos[0]-ppos[0],2)+pow(mpos[1]-ppos[1],2))
			if dist < 1.5:
				dam = float(randint(self.minDamage,self.maxDamage))
				weapon = screen.parent.inventoryPane.getWeapon()
				if weapon is not None:
					dam = dam * (1-weapon.getDefense())
					screen.parent.addLine("%s hit you for %0.1f points of damage." % (self.getLDesc(),dam))
					player.hitPoints = float(player.hitPoints)-dam
					self.playSound()
					print "%f hp remain" % (player.hitPoints)
					if player.hitPoints <= 0.0:
						screen.parent.addLine("You have been defeated!")
						player.setPos((2,2))
						player.hitPoints = player.maxHitPoints
						player.deaths = player.deaths + 1
						return
						
		choices = []
		dx = 0
		dy = 0
		nch = []
		f = None
		
		if spot.getScent() > 0:
			#print "on the trail",self
			bestSmell = spot.getScent()
			bestFace = None
			for f in ALLDIRS:
				if self.canMove(f,board,group):
					npos = board.getAt(self.newPos[0],self.newPos[1])
					if npos.getScent() > bestSmell:
						bestFace = f
						bestSmell = npos.getScent()
			if bestFace is not None:
				choices = [bestFace]
		else:
			if self.mood == M_HOSTILE:
				dx = ppos[0] - pos[0]
				dy = ppos[1] - pos[1]
			else:
				if self.goal == None or self.goal == pos:
					self.goal = (randint(1,ROOMW-2),randint(1,ROOMH-2))
				dx = self.goal[0] - pos[0]
				dy = self.goal[1] - pos[1]
		
			if dx < 0 and dy < 0:
				f = NW
				nch = [W,N]
			elif dx == 0 and dy < 0:
				f = N
				nch = [NW,NE]
			elif dx > 0 and dy < 0:
				f = NE
				nch = [N,E]
			elif dx < 0 and dy == 0:
				f = W
				nch = [NW,SW]
			elif dx > 0 and dy == 0:
				f = E
				nch = [NE,SE]
			elif dx < 0 and dy > 0:
				f = SW
				nch = [W,S]
			elif dx == 0 and dy > 0:
				f = S
				nch = [SW,SE]
			elif dx > 0 and dy > 0:
				f = SE
				nch = [S,E]
				
			if f is not None:
				if self.canMove(f,board,group):
					choices = [f]
				else:
					for f in nch:
						if self.canMove(f,board,group):
							choices.append(f)
		
		if len(choices) == 0:
			for f in ALLDIRS:
				if self.canMove(f,board,group):
					choices.append(f)

		if len(choices) > 0:
			f = choice(choices)
			if f is not None:
				self.move(f,board,group)

	def move(self,facing,board,group):
		self.setDir(facing)
		okay = self.canMove(facing,board,group)
		if okay:
			self.pos = self.newPos
		return okay

mtypes = ['a baby','a wild','a rabid','a mean','a dire','an ancient','a scarred','a quick','a nasty','a clever','an amazing','a giant']

class Rat(Monster):
	def __init__(self,level=0):
		Monster.__init__(self)
		level = min(level,len(mtypes)-3)
		self.setDesc('Dire Rat')
		self.setLDesc('%s rat' % (mtypes[level+randint(0,2)]))
		self.setType(O_MONSTER)
		self.setImageName('rat-top.png')
		self.setTargetImageName('01-rat-fr.png')
		self.hitPoints = randint(6,10)+level
		self.maxHitPoints = self.hitPoints
		self.minDamage = 2+level
		self.maxDamage = 6+level
		self.level = level
		self.setSoundName('rat.wav')

class Bird(Rat):
	def __init__(self,level=0):
		Rat.__init__(self)
		self.setDesc('Dangerous Bird')
		self.setLDesc('%s bird' % (mtypes[level+randint(0,2)]))
		self.setType(O_MONSTER)
		self.setImageName('bird-top.png')
		self.setTargetImageName('bird-fr.jpg')
		self.setSoundName('bird.wav')
		
class Bug(Rat):
	def __init__(self,level=0):
		Rat.__init__(self,level)
		self.setDesc('Nasty Bug')
		self.setLDesc('%s bug' % (mtypes[level+randint(0,2)]))
		self.setType(O_MONSTER)
		self.setImageName('bug-top.png')
		self.setTargetImageName('bug-fr.jpg')
		self.setSoundName('bug.wav')
		
class Penguin(Rat):
	def __init__(self,level=0):
		Rat.__init__(self,level)
		self.setDesc('Criminal Mastermind')
		self.setLDesc('%s penguin' % (mtypes[level+randint(0,2)]))
		self.setType(O_MONSTER)
		self.setImageName('penguin-top.png')
		self.setTargetImageName('penguin-fr.jpg')
		self.setSoundName('penguin.wav')
		
class Robot(Rat):
	def __init__(self,level=0):
		Rat.__init__(self,level)
		self.setDesc('Clanking Disaster')
		self.setLDesc('%s robot' % (mtypes[level+randint(0,2)]))
		self.setType(O_MONSTER)
		self.setImageName('robot-top.png')
		self.setTargetImageName('robot-fr.jpg')
		self.setSoundName('robot.wav')

class Boss(Rat):
	def __init__(self,level=0):
		Rat.__init__(self,level)
		self.setDesc('Stein!')
		self.setLDesc('The Boss')
		self.setType(O_MONSTER)
		self.setImageName('boss-top.png')
		self.setTargetImageName('boss-fr.jpg')
		self.setSoundName('slap.wav')
		self.hitPoints = 50
		self.maxHitPoints = self.hitPoints
		self.minDamage = 1
		self.maxDamage =8
		self.level = 5


mobTypes = [Rat,Bird,Bug,Penguin,Robot]

def generateBoss(group):
	awesome = getAwesome()
	boss = Boss()
	boss.setPos(awesome.getPos())
	boss.moving = False
	group.add(boss,layer=boss.getType())

def generateMonsters(group,n=NMONSTERS,level=0):
	for x in range(n):
		placed = False
		while not placed:
			pos = (randint(1,ROOMW-2),randint(1,ROOMH-2))
			placed = True
			for o in group:
				if o.getPos() == pos:
					placed = False
					break
			if placed:
				m = choice(mobTypes)(level)
				m.setPos(pos)
				group.add(m,layer=m.getType())

