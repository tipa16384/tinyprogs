# player.py

from gamevars import *
from monster import Monster
from sword import NewbieSword
from soundLibrary import getSound
from items import getAwesome

class Player(Monster):
	def __init__(self):
		print "player: initializing"
		Monster.__init__(self)
		self.setDesc('Player')
		self.setLDesc('the player')
		self.setType(O_PLAYER)
		self.setImageName(PLAYERFN)
		self.setTargetImageName('00-player-fr.png')
		self.setPos((2,2))
		self.steps = 0
		self.deaths = 0
		self.weapon = NewbieSword()
		self.weapon.targeted = True
		self.inventory = [self.weapon]
		self.hitPoints = 20.0
		self.maxHitPoints = self.hitPoints
		
		self.setDir(N)

	def getHeld(self):
		for g in self.inventory:
			if g.targeted:
				return g

	def move(self,facing,board,group):
		if Monster.move(self,facing,board,group):
			self.playSound()
			self.steps = self.steps+1
			spot = board.getAt(self.pos[0],self.pos[1])
			spot.setScent(self.steps)
			#print "player at",self.getPos()
			
			awesome = getAwesome()
			
			if awesome is not None and self.getPos() == awesome.getPos():
				awesome.playSound()

	def pickUp(self,obj):
		if not obj in self.inventory:
			self.inventory.append(obj)
