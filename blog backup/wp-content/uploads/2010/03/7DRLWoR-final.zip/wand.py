# wand.py

from gamevars import *
import pygame
import pygame.time
from pygame.locals import *
from pygame.sprite import *
import pygame.event
from pygame import Rect
from random import randint, choice, shuffle, random

from weapon import Weapon

names = ['an oak','a plastic','a marble','a glowing','a supple','a rubber']
props = ['paralysis','freezing','magic missiles','invisibility','haste','slow']

shuffle(names)

class Wand(Weapon):
	def __init__(self,level=1):
		Weapon.__init__(self)
		i = randint(0,len(names)-1)
		self.name = names[i]
		self.prop = props[i]
		self.desc = "Wand"
		self.setImageName('wand.png')
		self.maxDist = 100
		self.minDamage = 1+self.quality
		self.maxDamage = 6+self.quality
		self.verb = 'zapped'
		self.resist = 0.30
		self.defense = 0.10
		self.charges = randint(2,10)
		self.setSoundName('zap.wav')

	def getDefense(self):
		return self.defense + 0.05 * self.quality
	
	def getDesc(self):
		return self.name+' wand'
	
	def getLDesc(self):
		return self.getDesc()+' of '+self.prop
