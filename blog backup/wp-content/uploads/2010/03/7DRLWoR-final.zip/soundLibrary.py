# soundLibrary.py

import os
from pygame.mixer import Sound, init

_FOLDER = 'sounds'

sounds = {}

def getSound(fn):
	init()
	
	if fn in sounds:
		return sounds[fn]
	
	path = os.path.join(_FOLDER,fn)
	sound = Sound(path)
	
	if sound is None:
		print "couldn't load sound",fn
	else:
		print "sound %s loaded!" % (fn)
	
	sounds[fn] = sound
	return sound

