# globals.py

_WALL = '@'
_EMPTY = ' '
_BASE = 'a'

