# screen.py

from gamevars import *
import pygame
import pygame.time
from pygame.locals import *
from pygame.sprite import *
import pygame.event
from pygame import Rect
from random import randint, random
from monster import generateMonsters, generateBoss
from otarget import Target
from gamescreen import GameScreen
from math import sqrt, pow
from items import generateItems

class Screen(GameScreen):
	def __init__(self,parent,master,bounds):
		print "initializing screen"
		GameScreen.__init__(self,parent,master,bounds)
		
		self.mobs = LayeredDirty()
		self.scrollPos = (0,0)
		self.player = None
		self.chroma = pygame.Color(BGCOLOR)
		self.visitedFloorColor = {}
		self.screen.fill(self.chroma)
		self.targetPane = None
	
	def setTargetPane(self,tp):
		self.targetPane = tp
		
	def setMonsters(self):
		generateMonsters(self.mobs)
		generateBoss(self.mobs)
		
	def setItems(self):
		generateItems(self.mobs)
		
	def setPlayer(self,p):
		self.mobs.add(p,layer=p.getType())
		self.player = p
		self.target = Target()
		self.mobs.add(self.target,layer=self.target.getType())
			
		print "player pos",p.pos

	def moveMobs(self,board):
		chp = self.player.hitPoints
		for g in self.mobs:
			if g.getType() == O_MONSTER:
				g.doSomething(board,self.player,self.mobs,self)
		if self.player.hitPoints != chp:
			self.parent.addLine('You have %0.f hit points remaining.' % (self.player.hitPoints))
			
	
	def scroll(self):
		p = self.player
		sw = self.scrollPos[0]
		sh = self.scrollPos[1]
		
		if p is not None:
			if (p.pos[0]-sw) < POSLAG:
				sw = p.pos[0] - POSLAG
			if (sw+PORTSIZE[0]-p.pos[0]) < POSLAG:
				sw = p.pos[0]+POSLAG-PORTSIZE[0]
			if (p.pos[1]-sh) < POSLAG:
				sh = p.pos[1] - POSLAG
			if (sh+PORTSIZE[1]-p.pos[1]) < POSLAG:
				sh = p.pos[1]+POSLAG-PORTSIZE[1]
			if sw < 0:
				sw = 0
			if sw+PORTSIZE[0] > ROOMW:
				sw = ROOMW - PORTSIZE[0]
			if sh < 0:
				sh = 0
			if sh+PORTSIZE[1] > ROOMH:
				sh = ROOMH - PORTSIZE[1]

		self.scrollPos = (sw,sh)
		
	def updateObjects(self,board,grp):
		#print "updating group",g
		
		self.target.visible = 0
		for g in grp:
			if g.targeted:
				self.target.visible = 1
				self.target.setPos(g.getPos())
				break
		
		grp.update(self.scrollPos,board,self.player)
		grp.draw(self.screen)
	
	
	def drawBG(self,board):
		self.screen.fill(self.chroma)
		ppos = self.player.getPos()
		psym = board.getAt(ppos[0],ppos[1]).getCode()
	
		board.setSeen(psym)
	
		self.drawDeadRooms(board,psym)
		self.drawRooms(board,psym,False)
		self.drawGrid()
		self.drawRooms(board,psym,True)
	
	def drawDeadRooms(self,board,xsym):
		for x in range(self.scrollPos[0],self.scrollPos[0]+PORTSIZE[0]):
			for y in range(self.scrollPos[1],self.scrollPos[1]+PORTSIZE[1]):
				spot = board.getAt(x,y)
				if not spot.isRoom() or spot.getCode() == xsym or not board.isSeen(spot.getCode()):
					continue
				rx = (x-self.scrollPos[0]) * OSIZE
				ry = (y-self.scrollPos[1]) * OSIZE
				if spot.getCode() not in self.visitedFloorColor:
					self.visitedFloorColor[spot.getCode()] = pygame.Color(randint(230,250),randint(230,250),randint(230,250))
				self.screen.fill(self.visitedFloorColor[spot.getCode()],Rect(rx,ry,OSIZE,OSIZE))
				
	def drawRooms(self,board,xsym,show):
		for x in range(self.scrollPos[0],self.scrollPos[0]+PORTSIZE[0]):
			for y in range(self.scrollPos[1],self.scrollPos[1]+PORTSIZE[1]):
				spot = board.getAt(x,y)

				if not show:
					if not spot.isRoom():
						continue
					psym = spot.getCode()
					if not board.isSeen(psym):
						continue
				elif spot.getCode() != xsym:
					continue
				else:
					psym = xsym
					
				if spot.getCode() == psym:
					rx = (x-self.scrollPos[0]) * OSIZE
					ry = (y-self.scrollPos[1]) * OSIZE
					spot = board.getAt(x-1,y)
					if spot.getCode() != psym:
						color = show and self.borderColor or self.grayColor
						if spot.look(E) is not None:
							#print "door w"
							color = self.doorColor
						r = Rect(rx-BSIZE/2,ry,BSIZE,OSIZE)
						if not show:
							color = self.grayColor
						self.screen.fill(color,r)
						pygame.draw.circle(self.screen,color,(rx,ry),BSIZE/2)
						pygame.draw.circle(self.screen,color,(rx,ry+OSIZE),BSIZE/2)
					spot = board.getAt(x+1,y)
					if spot.getCode() != psym:
						color = self.borderColor
						if spot.look(W) is not None:
							#print "door e"
							color = self.doorColor
						if not show:
							color = self.grayColor
						r = Rect(rx+OSIZE-BSIZE/2,ry,BSIZE,OSIZE)
						self.screen.fill(color,r)
						pygame.draw.circle(self.screen,color,(rx+OSIZE,ry),BSIZE/2)
						pygame.draw.circle(self.screen,color,(rx+OSIZE,ry+OSIZE),BSIZE/2)
					spot = board.getAt(x,y-1)
					if spot.getCode() != psym:
						color = self.borderColor
						if spot.look(S) is not None:
							#print "door n"
							color = self.doorColor
						if not show:
							color = self.grayColor
						r = Rect(rx,ry-BSIZE/2,OSIZE,BSIZE)
						self.screen.fill(color,r)
						pygame.draw.circle(self.screen,color,(rx,ry),BSIZE/2)
						pygame.draw.circle(self.screen,color,(rx+OSIZE,ry),BSIZE/2)
					spot = board.getAt(x,y+1)
					if spot.getCode() != psym:
						color = self.borderColor
						if spot.look(N) is not None:
							#print "door s"
							color = self.doorColor
						if not show:
							color = self.grayColor
						r = Rect(rx,ry+OSIZE-BSIZE/2,OSIZE,BSIZE)
						self.screen.fill(color,r)
						pygame.draw.circle(self.screen,color,(rx,ry+OSIZE),BSIZE/2)
						pygame.draw.circle(self.screen,color,(rx+OSIZE,ry+OSIZE),BSIZE/2)
	
	def click(self,button,pos):
		x = pos[0]/OSIZE + self.scrollPos[0]
		y = pos[1]/OSIZE + self.scrollPos[1]
		gpos = (x,y)
		targeted = None
		
		for g in self.mobs:
			if g.getPos() == gpos and g.getType() > O_TARGET and (targeted is None or g.getType() > targeted.getType()):
				targeted = g

		for g in self.mobs:
			if g == targeted:
				g.targeted = True
			else:
				g.targeted = False
	
		if self.targetPane is not None:
			self.targetPane.setTarget(targeted)
			if targeted is not None:
				self.parent.addLine('You see %s' % (targeted.getLDesc()))
	
	def pickUp(self):
		ppos = self.player.getPos()
		pspot = self.board.getAt(ppos[0],ppos[1])

		for g in self.mobs:
			if g.getType() == O_GENERIC and g.getPos() == ppos:
				if g.targeted:
					g.targeted = False
					self.targetPane.setTarget(None)
				self.player.inventory.append(g)
				self.mobs.remove(g)
				self.parent.addLine('You have picked up %s' % (g.getLDesc()))
				
	
	def killMonster(self):
		mob = None
		ppos = self.player.getPos()
		pspot = self.board.getAt(ppos[0],ppos[1])
		psym = pspot.getCode()

		
		for g in self.mobs:
			if g.getType() != O_MONSTER:
				continue
			if not g.targeted:
				continue
			gpos = g.getPos()
			gspot = self.board.getAt(gpos[0],gpos[1])
			gsym = gspot.getCode()
			if gsym != psym:
				continue
			mob = g
			break
		
		weapon = self.parent.inventoryPane.getWeapon()
		
		if weapon.charges == 0:
			self.parent.addLine('%s is out of charges!' % (weapon.getLDesc()))
			return
		
		zap = False
		
		if mob is not None and self.targetPane is not None:
			if mob.getType() == O_MONSTER:
				mpos = mob.getPos()
				dist = sqrt(pow(mpos[0]-ppos[0],2)+pow(mpos[1]-ppos[1],2))
				if dist <= float(weapon.maxDist):
					zap = True
				else:
					self.parent.addLine('%s is too far away!' % (mob.getLDesc()))
			
			if zap:
				weapon.playSound()
				dam = randint(weapon.minDamage,weapon.maxDamage)
				self.parent.addLine('You %s %s for %d points of damage!' % (weapon.verb,mob.getLDesc(),dam))
				mob.hitPoints = mob.hitPoints - dam
				if weapon.charges > 0:
					weapon.charges = weapon.charges - 1
					if weapon.charges == 0:
						self.parent.addLine('The last of the mystical energy trickles from %s....' % (weapon.getLDesc()))
						weapon.quality = -1
					elif weapon.charges == 1:
						self.parent.addLine('Mystic energies flicker weakly around %s' % (weapon.getLDesc()))
						
				if mob.hitPoints <= 0:
					level = mob.level
					self.targetPane.setTarget(None)
					self.mobs.remove(mob)
					self.parent.addLine('You have killed %s with %s!' % (mob.getLDesc(),weapon.getLDesc()))
					if random() < 0.5:
						generateMonsters(self.mobs,level+1)
				else:
					print "mob has %d hit points remaining" % (mob.hitPoints)

	def keystroke(self,key):
		moveDir = None
		moveMonsters = False
		if key == K_q:
			self.userQuit = True
		elif key == K_h:
			moveDir = W
		elif key == K_j:
			moveDir = S
		elif key == K_k:
			moveDir = N
		elif key == K_l:
			moveDir = E
		elif key == K_y:
			moveDir = NW
		elif key == K_u:
			moveDir = NE
		elif key == K_n:
			moveDir = SW
		elif key == K_m:
			moveDir = SE
		elif key == K_PERIOD:
			moveMonsters = True
		elif key == K_f:
			moveMonsters = True
			self.killMonster()
		elif key == K_COMMA:
			moveMonsters = True
			self.pickUp()

		if moveDir != None:
			self.player.move(moveDir,self.board,self.mobs)
			moveMonsters = True
				
		if moveMonsters:
			self.moveMobs(self.board)
	
	def draw(self):
		self.scroll()
		self.drawBG(self.board)
		self.updateObjects(self.board,self.mobs)
		