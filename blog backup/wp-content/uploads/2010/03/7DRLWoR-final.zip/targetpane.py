# targetpane.py

from gamevars import *
import pygame
import pygame.time
from pygame.locals import *
from pygame.sprite import *
import pygame.event
from pygame import Rect
from random import randint
from monster import generateMonsters
from otarget import Target
from gamescreen import GameScreen
from medialibrary import getMedia

class TargetPane(GameScreen):
	def __init__(self,parent,masterScreen,bounds):
		self.target = None
		self.psize = 128
		self.border = 3
		bounds = Rect(bounds.x+(bounds.width-self.psize-self.border)/2,bounds.y,self.psize+self.border*2,self.psize+self.border*2+20)
		GameScreen.__init__(self,parent,masterScreen,bounds)
	
	def draw(self):
		borderRect = Rect(0,10,self.psize+self.border*2,self.psize+self.border*2)
		pictRect = Rect(self.border,10+self.border,self.psize,self.psize)
		self.screen.fill(Color('black'),borderRect)
		self.screen.fill(Color('white'),pictRect)
		
		object = None
		
		if self.parent.mapScreen is not None:
			for g in self.parent.mapScreen.mobs:
				if self.parent.inPlayerRoom(g) and g.targeted:
					object = g
					break
		
		if object is None and self.parent.player is not None:
			for g in self.parent.player.inventory:
				if g.targeted:
					object = g
					break
		
		if object is None:
			object = self.parent.player
		
		if object is not None:
			media = object.getTargetImage()
			if media is not None:
				image = media.getTargetImage(self.psize)
				self.screen.blit(image,(self.border+(self.psize-image.get_width())/2,self.border+10+(self.psize-image.get_height())/2))

	def setTarget(self,obj):
		self.target = obj
