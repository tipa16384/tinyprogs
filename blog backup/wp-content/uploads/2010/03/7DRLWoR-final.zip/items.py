# items.py

from gamevars import *
from random import randint, random

from wand import Wand
from sword import Sword
from object import Object

class Awesome(Object):
	def __init__(self):
		Object.__init__(self)
		self.desc = "Awesome Spot"
		self.setImageName('superawesome.png')
		self.setType(O_FINISH)
		self.setSoundName('win.wav')
		
awesome = Awesome()

def getAwesome():
	return awesome

def generateItems(group):
	global awesome
	
	wall = 2
	
	if wall == 0:
		pos = (randint(3,ROOMW-3),ROOMH-3)
	elif wall == 1:
		pos = (ROOMW-3,randint(3,ROOMH-3))
	else:
		pos = (ROOMW-3,ROOMH-3)

	awesome.setPos(pos)
	group.add(awesome,layer=O_FINISH)
	
	print "awesome pos",awesome.getPos()
	
	for i in range(NITEMS):
		if random() < 0.5:
			w = Wand()
		else:
			w = Sword()
		group.add(w,layer=O_GENERIC)

