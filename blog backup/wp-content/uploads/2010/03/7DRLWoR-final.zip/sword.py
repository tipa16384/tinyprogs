# sword.py

from gamevars import *
import pygame
import pygame.time
from pygame.locals import *
from pygame.sprite import *
import pygame.event
from pygame import Rect
from random import randint, choice, shuffle, random

from object import Object
from meleeWeapon import MeleeWeapon

names = ['a wooden','a rusty','a tin','an iron','a steel','an onyx']

class Sword(MeleeWeapon):
	def __init__(self,level=1):
		MeleeWeapon.__init__(self)
		i = randint(max(level-1,0),min(level+1,len(names)-1))
		self.name = names[i]
		#self.prop = props[i]
		self.desc = "Sword"
		self.setImageName('sword.png')
		self.minDamage = 1+self.quality+level
		self.maxDamage = 6+self.quality+level
		self.verb = 'slashed'
		self.defense = 0.20
		self.resist = 0.10
		self.level = i
		self.setSoundName('sword.wav')
		
	def getDesc(self):
		return self.name+' sword'

	def getLDesc(self):
		if self.level > 0:
			return '%s +%d' % (self.getDesc(),self.level)
		elif self.level < 0:
			return '%s %d' % (self.getDesc(),self.level)
		else:
			return self.getDesc()

class NewbieSword(Sword):
	def __init__(self):
		Sword.__init__(self,0)
		self.minDamage = 1
		self.maxDamage = 5
		self.quality = -1
		self.verb = 'poked'
		self.level = 0
	
	def getDesc(self):
		return 'a pointed stick'
	
	def getLDesc(self):
		return self.getDesc()

