# controlScreen.py

from gamescreen import GameScreen

class ControlScreen(GameScreen):
	def __init__(self,parent,master,bounds):
		print "ControlScreen init"
		GameScreen.__init__(self,parent,master,bounds)

