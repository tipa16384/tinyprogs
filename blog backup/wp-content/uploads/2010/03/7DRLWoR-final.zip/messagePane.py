# messagePane.py

from gamevars import *
import pygame
import pygame.time
from pygame.locals import *
from pygame.sprite import *
import pygame.event
from pygame import Rect
from random import randint
from monster import generateMonsters
from otarget import Target
from gamescreen import GameScreen
from items import generateItems

class MessagePane(GameScreen):
	def __init__(self,parent,master,bounds):
		print "initializing message pane"
		GameScreen.__init__(self,parent,master,bounds)
		
		self.numLines = 5
		self.messages = []
		self.lineHeight = (bounds.height-20)/self.numLines
		self.fontHeight = self.lineHeight
		self.font = pygame.font.Font(FONTNAME,self.fontHeight)
		self.bgColor = Color('white')
		self.textColor = Color('black')
				
	def draw(self):
		self.screen.fill(self.bgColor)
		self.drawGrid()
		for i in range(self.numLines):
			mi = len(self.messages)-self.numLines+i
			if mi < 0 or mi >= len(self.messages):
				continue
			m = self.messages[mi]
			line = self.font.render(m, True, self.textColor)
			if line is not None:
				self.screen.blit(line,(10,10+i*self.lineHeight))

	def addLine(self,text):
		self.messages.append(text)
		self.messages = self.messages[-self.numLines:]

