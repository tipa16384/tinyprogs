# gamescreen.py

from gamevars import *
import pygame
import pygame.time
from pygame.locals import *
from pygame.sprite import *
import pygame.event
from pygame import Rect
from random import randint
from monster import generateMonsters
from otarget import Target

class GameScreen:
	def __init__(self,parent,masterScreen,bounds):
		self.screen = masterScreen.subsurface(bounds)
		self.board = None
		self.parent = parent
		self.graphColor = pygame.Color(0,200,255,75)
		self.borderColor = pygame.Color("black")
		self.doorColor = pygame.Color("red")
		self.grayColor = pygame.Color(200,200,200)
				
	def drawGrid(self):
		osize = OSIZE/2
		w = self.screen.get_width()
		h = self.screen.get_height()
		
		for x in range(0,w,osize):
			pygame.draw.line(self.screen,self.graphColor,(x,0),(x,h))
	
		for y in range(0,h,osize):
			pygame.draw.line(self.screen,self.graphColor,(0,y),(w,y))
	
	def draw(self):
		pass
	
	def click(self,button,pos):
		pass

	def keystroke(self,key):
		pass
	
	def setBoard(self,board):
		self.board = board
	
	def getBoard(self):
		return self.board
		