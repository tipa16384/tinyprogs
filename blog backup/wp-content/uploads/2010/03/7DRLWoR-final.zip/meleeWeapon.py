# meleeWeapon.py

from weapon import Weapon

class MeleeWeapon(Weapon):
	def __init__(self):
		Weapon.__init__(self)
		self.hitPlus = 0
		self.defense = 0.10

class BareHands(MeleeWeapon):
	def __init__(self):
		MeleeWeapon.__init__(self)
		self.defence = 0.05
		self.verb = 'slapped'
		self.desc = 'your bare hands'
		self.ldesc = 'your bare hands'
