# inventoryPane.py

from gamevars import *
import pygame
import pygame.time
from pygame.locals import *
from pygame.sprite import *
import pygame.event
from pygame import Rect
from random import randint
from monster import generateMonsters
from otarget import Target
from gamescreen import GameScreen
from items import generateItems
from object import Object
from meleeWeapon import BareHands

class InventoryPane(GameScreen):
	def __init__(self,parent,master,bounds):
		print "initializing message pane"
		GameScreen.__init__(self,parent,master,bounds)
		self.fontHeight = 30
		self.iconHeight = 36
		self.lineHeight = max(self.fontHeight,self.iconHeight)+4
		self.font = pygame.font.Font(None,self.fontHeight)
		self.bgColor = parent.bgColor
		self.selectedBgColor = Color('yellow')
		self.textColor = Color('black')
		self.makeHands()
		
	def getWeapon(self):
		weapon = self.hands
		player = self.parent.player
		if player is not None:
			for g in player.inventory:
				if g.targeted:
					weapon = g
					break
		return weapon
	
	def makeHands(self):
		self.hands = BareHands()
	
	def draw(self):
		player = self.parent.player
		if player is not None:
			i = 0
			for g in player.inventory:
				r = self.getIRect(i)
				if g.targeted:
					bgColor = self.selectedBgColor
					self.screen.fill(bgColor,r)
				else:
					bgColor = self.bgColor
				tm = g.targetMedia
				icon = tm.getIconImage(self.iconHeight)
				voffset = (r.height-icon.get_height())/2
				self.screen.blit(icon,(r.x,r.y+voffset))
				text = self.font.render(g.getDesc(), True, g.getColor(), bgColor)
				voffset = (r.height-text.get_height())/2
				self.screen.blit(text,(r.x+self.iconHeight+2,r.y+voffset))
				i = i + 1

	def getIRect(self,i):
		return Rect(0,self.lineHeight*i,self.screen.get_width(),self.lineHeight)

	def click(self,button,pos):
		ng = None
		og = None
		player = self.parent.player
		if player is not None:
			i = 0
			for g in player.inventory:
				r = self.getIRect(i)
				if g.targeted:
					og = g
				if r.collidepoint(pos):
					ng = g
				i = i + 1
		
		if ng is not None:
			if ng != og:
				if og is not None:
					self.parent.addLine('You are no longer wielding %s' % (og.getLDesc()))
					og.targeted = False
				ng.targeted = True
				self.parent.addLine('You are now wielding %s' % (ng.getLDesc()))
				print ng
			else:
				self.parent.addLine('You are no longer wielding %s' % (ng.getLDesc()))
				ng.targeted = False

	def keystroke(self,key):
		if key == K_d:
			weapon = self.getWeapon()
			player = self.parent.player
			
			if weapon is None or weapon == self.hands:
				self.parent.addLine('Your hands are empty!')
			else:
				weapon.targeted = False
				weapon.setPos(player.getPos())
				player.inventory.remove(weapon)
				self.parent.mapScreen.mobs.add(weapon,layer=weapon.getType())
				self.parent.addLine('You have dropped %s' % (weapon.getLDesc()))
