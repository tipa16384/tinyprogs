# weapon.py

from object import Object

from gamevars import *
import pygame
import pygame.time
from pygame.locals import *
from pygame.sprite import *
import pygame.event
from pygame import Rect
from random import randint, choice, shuffle, random

colors = [Color('black'),Color('green'),Color('blue'),Color('red'),Color('purple')]

class Weapon(Object):
	def __init__(self):
		Object.__init__(self)
		self.maxDist = 1.5
		self.minDamage = 1
		self.maxDamage = 1
		self.verb = 'hit'
		self.hitPlus = 0
		self.defense = 0.10
		self.resist = 0.10
		self.charges = -1
		
		q = random()
		
		if q < 0.25:
			self.quality = 0
		elif q < 0.75:
			self.quality = 1
		elif q < 0.85:
			self.quality = 2
		elif q < 0.95:
			self.quality = 3
		else:
			self.quality = 4
	
	def getDefense(self):
		return self.defense + 0.1 * self.quality
	
	def getResists(self):
		return self.resist + 0.1 * self.quality
	
	def getColor(self):
		if self.quality >= 0 and self.quality < len(colors):
			return colors[self.quality]
		elif self.quality < 0:
			return Color('gray')
		else:
			return colors[0]

	def __str__(self):
		return self.getLDesc()+' dist=%d min=%d max=%d verb=%s hitPlus=%d def=%f res=%f charges=%d' % (self.maxDist,self.minDamage,self.maxDamage, \
			self.verb, self.hitPlus, self.getDefense(), self.getResists(), self.charges)

