# masterScreen.py

from gamevars import *
import pygame
import pygame.time
from pygame.locals import *
from pygame.sprite import *
import pygame.event
from pygame import Rect
from random import randint
from monster import generateMonsters
from otarget import Target
from gamescreen import GameScreen
from titlepane import TitlePane
from targetpane import TargetPane
from messagePane import MessagePane
from inventoryPane import InventoryPane

from screen import Screen
from controlScreen import ControlScreen

class MasterScreen:
	def __init__(self):
		pygame.init()

	def initScreen(self):
		self.graphColor = pygame.Color(0,200,255,75)
		self.masterScreen = pygame.display.set_mode((SCREENW,SCREENH))
		self.subScreens = []
		self.mapScreen = Screen(self,self.masterScreen,Rect(CONTROLSW,0,PORTW,PORTH))
		self.subScreens.append(self.mapScreen)
		self.subScreens.append(ControlScreen(self,self.masterScreen,Rect(0,0,CONTROLSW,PORTH)))
		self.bgColor = Color('white')
		self.player = None
		self.board = None
		
		cpHeight = 0
		
		titlePane = TitlePane(self,self.masterScreen,Rect(0,cpHeight,CONTROLSW,SCREENH))
		cpHeight = cpHeight + titlePane.screen.get_height()
		self.subScreens.append(titlePane)
		print "cpHeight",cpHeight
		
		targetPane = TargetPane(self,self.masterScreen,Rect(0,cpHeight,CONTROLSW,SCREENH))
		cpHeight = cpHeight + targetPane.screen.get_height()
		self.subScreens.append(targetPane)
		self.mapScreen.setTargetPane(targetPane)
		
		self.inventoryPane = InventoryPane(self,self.masterScreen,Rect(10,cpHeight,CONTROLSW-20,SCREENH-cpHeight))
		self.subScreens.append(self.inventoryPane)

		self.messagePane = MessagePane(self,self.masterScreen,Rect(CONTROLSW,PORTH,PORTW,MSGH))
		self.subScreens.append(self.messagePane)
	
		self.addLine('7DRL 2010, Day 7')
		self.addLine('Welcome to the World of Roguecraft!')
		
		pygame.display.flip()

	def getObjectSpot(self,o):
		if o is None or self.board is None:
			return None
		pos = o.getPos()
		return self.board.getAt(pos[0],pos[1])

	def getPlayerSpot(self):
		return self.getObjectSpot(self.player)

	def inPlayerRoom(self,obj):
		ospot = self.getObjectSpot(obj)
		pspot = self.getPlayerSpot()
		return ospot is not None and pspot is not None and obj in self.mapScreen.mobs and ospot.getCode() == pspot.getCode()

	def addLine(self,text):
		self.messagePane.addLine(text)

	def setPlayer(self,player):
		self.mapScreen.setPlayer(player)
		self.mapScreen.setItems()
		self.mapScreen.setMonsters()
		self.player = player

	def setBoard(self,board):
		self.board = board
		for gs in self.subScreens:
			gs.setBoard(board)

	def click(self,button,pos):
		for gs in self.subScreens:
			offs = gs.screen.get_offset()
			size = gs.screen.get_size()
			npos = (pos[0]-offs[0],pos[1]-offs[1])
			if npos[0] >= 0 and npos[1] >= 0 and npos[0] < size[0] and npos[1] < size[1]:
				gs.click(button,npos)

	def keystroke(self,key):
		for gs in self.subScreens:
			gs.keystroke(key)

	def drawGrid(self):
		osize = OSIZE/2
		w = self.masterScreen.get_width()
		h = self.masterScreen.get_height()
		
		for x in range(0,w,osize):
			pygame.draw.line(self.masterScreen,self.graphColor,(x,0),(x,h))
	
		for y in range(0,h,osize):
			pygame.draw.line(self.masterScreen,self.graphColor,(0,y),(w,y))
	
	def draw(self):
		self.masterScreen.fill(self.bgColor)
		self.drawGrid()
		for gs in self.subScreens:
			gs.draw()
		pygame.display.flip()
