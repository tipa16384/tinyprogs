#!/usr/bin/python

from board import Board
from screen import Screen
import pygame
import pygame.time
from pygame.locals import *
import pygame.event
from player import Player
from gamevars import *
from gamescreen import GameScreen
from masterScreen import MasterScreen
import os

class Main:
	def __init__(self):
		self.board = Board()
		self.screen = MasterScreen()
		self.userQuit = False
		self.updateBoard = True
		
		self.initialize()
		
		self.player = Player()
		self.screen.setPlayer(self.player)
	
	def initialize(self):
		os.environ['SDL_VIDEO_CENTERED'] = '1'	# center the screen
		self.board.setUp()
		self.screen.initScreen()
		self.screen.setBoard(self.board)
		
	def printBoard(self):
		self.board.show()

	def processEvents(self):
		e = pygame.event.poll()
		if e is not None:
			if e.type == MOUSEBUTTONDOWN:
				self.screen.click(e.button,e.pos)
				self.updateBoard = True
			elif e.type == KEYDOWN:
				self.updateBoard = True
				if e.key == K_q:
					self.userQuit = True
				else:
					self.screen.keystroke(e.key)
	
	def run(self):
		print "running..."
		while not self.userQuit:
			if self.updateBoard:
				self.screen.draw()
				self.updateBoard = False
			pygame.time.wait(5)
			self.processEvents()
		pygame.quit()

main = Main()
main.printBoard()

main.run()
