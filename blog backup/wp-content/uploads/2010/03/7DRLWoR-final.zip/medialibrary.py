# medialibrary.py

from pygame.image import *
from pygame.transform import *
from pygame.sprite import Sprite
from pygame import Rect

from gamevars import *
from random import randint
import os


_library = {}

def getMedia(fn):
	if fn in _library:
		return _library[fn]
	
	m = Media()
	m.setImageName(fn)
	m.loadImage()
	_library[fn] = m
	return m

class Media:
	def __init__(self):
		self.imageFileName = ''
		self.srcImage = None
		self.targetImage = None
		self.iconImage = None
		self.rotations = {N:None, E:None, W:None, S:None, NE:None, NW:None, SE:None, SW:None}

	def getImageName(self):
		return self.imageFileName
	
	def setImageName(self,name):
		self.imageFileName = name
		self.loadImage()
	
	def loadImage(self):
		fn = os.path.join(IMAGEDIR,self.imageFileName)
		print "Media: loading image",fn
		self.srcImage = load(fn)
		print "-- Media loaded:",self.srcImage
	
	def getTargetImage(self,width):
		if self.targetImage is None:
			swidth = self.srcImage.get_width()
			sheight = self.srcImage.get_height()
			if swidth > sheight:
				dwidth = width
				dheight = (width*sheight)/swidth
			else:
				dwidth = (width*swidth)/sheight
				dheight = width
			self.targetImage = scale(self.srcImage,(dwidth,dheight))
		return self.targetImage
	
	def getIconImage(self,width):
		if self.iconImage is None:
			swidth = self.srcImage.get_width()
			sheight = self.srcImage.get_height()
			if swidth > sheight:
				dwidth = width
				dheight = (width*sheight)/swidth
			else:
				dwidth = (width*swidth)/sheight
				dheight = width
			self.iconImage = scale(self.srcImage,(dwidth,dheight))
		return self.iconImage
	
	def getSrcImage(self):
		return self.srcImage
			
	def getImage(self,facing=N):
		if self.srcImage is not None and self.rotations[facing] is None:
			iwidth = self.srcImage.get_width()
			iheight = self.srcImage.get_height()
			if iwidth > iheight:
				swidth = OSIZE_V
				sheight = (iheight*OSIZE_V)/iwidth
			else:
				swidth = (iwidth*OSIZE_V)/iheight
				sheight = OSIZE_V
			img = scale(self.srcImage,(swidth,sheight))
			if facing != N:
				deg = 0
				if facing == NW:
					deg = 45
				elif facing == W:
					deg = 90
				elif facing == SW:
					deg = 135
				elif facing == S:
					deg = 180
				elif facing == SE:
					deg = -135
				elif facing == E:
					deg = -90
				elif facing == NE:
					deg = -45
				img = rotate(img,deg)
			self.rotations[facing] = img
		return self.rotations[facing]
