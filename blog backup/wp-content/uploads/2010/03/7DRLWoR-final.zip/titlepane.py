# titlepane.py

from gamevars import *
import pygame
import pygame.time
from pygame.locals import *
from pygame.sprite import *
import pygame.event
from pygame import Rect
from random import randint
from monster import generateMonsters
from otarget import Target
from gamescreen import GameScreen
from medialibrary import getMedia

class TitlePane(GameScreen):
	def __init__(self,parent,masterScreen,bounds,fn='title.png'):
		self.load(fn,bounds)
		nbounds = Rect(0,0,bounds.width,self.image.get_height()+20)
		GameScreen.__init__(self,parent,masterScreen,nbounds)
	
	def load(self,fn,bounds):
		self.media = getMedia(fn)
		image = self.media.getSrcImage()
		width = bounds.width - 20
		mwidth = image.get_width()
		height = (image.get_height()*width)/mwidth
		self.image = pygame.transform.scale(image,(width,height))
	
	def draw(self):
		self.screen.blit(self.image,(10,10))

