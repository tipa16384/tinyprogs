<div class="body_right_search">
<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
<input type="text" value="<?php echo wp_specialchars($s, 1); ?>" name="s" id="s" class="searchbox" />
<input type="submit" id="searchsubmit" value="Search" class="buttonstyle"/>
</form>
</div>
