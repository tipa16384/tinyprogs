<?php get_header(); ?>
	<div class="body_box">
		
		<div class="body_left">

<!-- BLOG FORMAT -->
<?php $my_query = new WP_Query('showposts=1');
  while ($my_query->have_posts()) : $my_query->the_post();
  $do_not_duplicate = $post->ID; ?>
    	
<div class="blogbox" id="post-<?php the_ID(); ?>">
	
	<div class="entryheader">

		<div class="datecolumn">
			<div class="dateday"><?php the_time('jS') ?></div>
			<div class="datemonthyear"><?php the_time('F') ?><br /><?php the_time('Y') ?></div>
		</div>
		<div class="titlecolumn">
			<div class="entrytitle">
				<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a>
			</div>
			<div class="entrytitlecomment">
				FILED: <?php the_category(', ') ?> <?php edit_post_link('Edit', '', ' | '); ?> <br /><?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?>
			</div>
		</div>
		
	</div>


	<div class="entrybody">
	<?php the_content('<span class="entrymore">continue reading &raquo;</span>'); ?>
	</div>
	
</div>
<!-- BLOG FORMAT END -->		
 <?php endwhile; ?>		
			<div class="pagebody">
			<h1>Recent entries</h1>
<?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>
	
 
			
			<div class="excerpt_box" id="post-<?php the_ID(); ?>">
					<div class="titledate">
					<?php the_time('j.m.y') ?> | <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a>
					</div>
					<div class="thexcerpt"><?php the_excerpt(); ?></div>
			</div>
		
			
 <?php endwhile; endif; ?>
</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>