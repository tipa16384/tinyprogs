	</div>
	
<!-- FOOTER -->
  <div class="footer_box">
		<a href="feed:<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a>  and <a href="feed:<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a><br />
	  Powered by <a href="http://wordpress.org">WordPress</a>. <a href="http://filipinowebdesigner.com">Kurtina</a> theme by <a href="http://kutitots.com">Gail Dela Cruz</a>.	</div>
	
</div>
<?php ?>

<?php wp_footer(); ?>
</body>
</html>
