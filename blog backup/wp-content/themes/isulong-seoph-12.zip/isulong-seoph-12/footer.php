
<div id="footer">
		<p id="blog-footer">
		&copy; <?php echo(date('Y')); ?> <?php the_author('nickname'); ?>
		|
		Powered by <a href="http://wordpress.org/" title="WordPress">WordPress</a>
		|
		<a href="http://www.isulong-seoph.net/2006/06/14/i-present-to-you-isulong-seoph-wordpress-theme-v1/" title="Ituloy AngSulong" rel="follow">Isulong SEOPH</a> theme by <a href="http://ituloy-angsulong.isulong-seoph.net/" title="Ituloy AngSulong" rel="follow">Ituloy AngSulong</a>
		| <!-- The following is a link to the theme author's sponsor. Please consider its smallness and that Scott was nice enough to make this theme publically available.. -->
		Sponsor: <a href="http://www.seo-webmarketing.com" title="Internet Marketing SEO">Internet Marketing SEO</a>
		|
		Valid <a href="http://validator.w3.org/check/referer" title="Valid XHTML 1.0 Strict" rel="nofollow">XHTML</a> &amp; <a href="http://jigsaw.w3.org/css-validator/validator?profile=css2&amp;warning=2&amp;uri=<?php bloginfo('stylesheet_url'); ?>" title="Valid CSS" rel="nofollow">CSS</a>
		|
		<a href="<?php bloginfo('rss2_url'); ?>" title="<?php bloginfo('name'); ?> RSS 2.0 (XML) Feed" rel="alternate" type="application/rss+xml">Posts RSS</a> &amp;  <a href="<?php bloginfo('comments_rss2_url'); ?>" title="<?php bloginfo('name'); ?> Comments RSS 2.0 (XML) Feed" rel="alternate" type="application/rss+xml">Comments RSS</a>
		<?php do_action('wp_footer'); ?> 
		</p>
</div>
</div>


</body>
</html>