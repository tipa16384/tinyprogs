	</div>



<div id="footer">

 <br /><?php echo sprintf(__("Proudly powered by <a class=\"footerLink\" href='http://wordpress.org' title='%s'>WordPress"), __("Proudly powered by WordPress, state-of-the-art semantic personal publishing platform")); ?> <?php bloginfo('version'); ?></a>. <br />

This theme started out as <A class="footerLink" href="http://www.thoughtmechanics.com/blog/templates">Benevolence</A><br /> and ended up as  <a class="footerLink" href="http://theloo.org/2005/03/06/borderline-chaos/">Borderline Chaos (1.9)</a>.  <br />It validates in <a class="footerLink" href="http://validator.w3.org/check/referer">XHTML</a> and <a class="footerLink" href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> minus plugins.
<br />

<a class="footerLink" href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a> is &copy; the Author. 

Care to <?php wp_loginout(); ?>?

<br />Syndicate entries using <a class="footerLink" href="<?php bloginfo('rss2_url'); ?>" title="<?php _e('Syndicate this site using RSS'); ?> ">

   <?php _e('<abbr title="Really Simple Syndication">RSS (Posts)</abbr>'); ?></a> or <a class="footerLink" href="<?php bloginfo('comments_rss2_url'); ?>">RSS (Comments)</a>.



<br /><br />

</div>



</div>



</body>

</html>

