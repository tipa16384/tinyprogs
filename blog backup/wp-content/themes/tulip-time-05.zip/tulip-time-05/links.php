<?php
/*
Template Name: Links
*/
?>

<?php get_header(); ?>

    <h2>Links:</h2>
    <ul>
    <?php get_links_list(); ?>
    </ul>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
