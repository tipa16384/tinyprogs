<?php get_header(); ?>

    <h2 class="center">Error 404 - Not Found</h2>

        <p>The page you were looking for doesn't seem to be here anymore!</p>
        <p>We may have moved or renamed it, or it might not have ever existed. Who knows? Certainly not us.</p>

        <p>If it's any help, try using the Search Box displayed. If that doesn't help then I guess we're all lost. Good Luck!</p>

        <?php include (TEMPLATEPATH . "/searchform.php"); ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
