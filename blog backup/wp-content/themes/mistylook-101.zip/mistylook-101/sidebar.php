<div id="sidebar">
<ul>
<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar() ) : else : ?>
<?php if(is_home()) { ?>
<li class="sidebox">
	<h2>About</h2>
	<p>
	<img src="<?php bloginfo('stylesheet_directory');?>/img/profile.jpg" alt="Profile" class="profile" />
	<strong><?php bloginfo('name');?></strong><br/><?php bloginfo('description');?>.<br/>
	There are <?php global $numposts; echo $numposts; ?> Posts and <?php global $numcmnts; echo $numcmnts;?> Comments so far.
	</p>	
</li>
<?php } ?>

<li class="sidebox">
	<h2><?php _e('Archives'); ?></h2>
	<ul><?php wp_get_archives('type=monthly&show_post_count=true'); ?></ul>
</li>

<li class="sidebox">
	<h2><?php _e('Tags'); ?></h2>
	<ul>
		<?php wp_list_cats('optioncount=1');    ?>
	</ul>		
</li>

<li class="sidebox">
	<h2><?php _e('Pages'); ?></h2>
	<ul><?php wp_list_pages('title_li=' ); ?></ul>	
</li>
<?php if(is_home()) { ?>
<li class="sidebox">
	<h2><?php _e('Links'); ?>
  </h2>
	<ul><?php get_links_list('name'); ?> </ul>		
</li>
<li class="sidebox">
	<h2><?php _e('Meta'); ?></h2>
	<ul>
		<?php wp_register(); ?>
		<li><?php wp_loginout(); ?></li>
		<li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
		<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
		<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
		<?php wp_meta(); ?>
	</ul>	
</li>
<?php }?>
  <?php endif; ?>
</ul>
</div><!-- end id:sidebar -->
</div><!-- end id:content -->
</div><!-- end id:container -->