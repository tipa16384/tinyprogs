<div id="footer">
<p><strong><?php bloginfo('name');?></strong> &copy; <?php echo date('Y');?> All Rights Reserved.</p>
<p class="right">
	<span><a href="http://wpthemes.info/misty-look/" title="MistyLook From WPThemes.Info">MistyLook</a> made free by <a href="http://www.webhostingbluebook.com" title="Web hosting Bluebook">Web hosting Bluebook</a></span>
<p>
<?php wp_footer();?>
</div><!-- end id:footer -->


</body>
</html>